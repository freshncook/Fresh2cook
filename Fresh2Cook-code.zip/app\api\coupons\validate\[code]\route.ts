import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: true,
    module: "Control Tower Live",
    timestamp: new Date().toISOString()
  });
}



