﻿import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: true,
    module: "Transactions",
    timestamp: new Date().toISOString()
  });
}





