﻿import PortalLogin from "@/components/portals/portal-login";
export default function AdminLoginPage() {
  return <PortalLogin role="admin" />;
}
