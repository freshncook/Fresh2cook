﻿"use client";
import "./admin-compact.css";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const groups = [
  { title: "OVERVIEW", links: [
    ["Dashboard", "/admin"],
  ]},
  { title: "ORDERS & DELIVERY", links: [
    ["Manual Assignment", "/admin/manual-assignment"],
    ["Delivery Control", "/admin/delivery"],
    ["Rider Approvals", "/admin/rider-approvals"],
  ]},
  { title: "MANAGEMENT", links: [
    ["Orders", "/admin/orders"],
    ["Customers", "/admin/customers"],
    ["Products", "/admin/products"],
    ["Inventory", "/admin/inventory"],
    ["Processing", "/admin/processing"],
  ]},
  { title: "REPORTS & SETTINGS", links: [
    ["Analytics", "/admin/analytics"],
    ["Settings", "/admin/settings"],
  ]},
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 md:flex">
      {open && <button aria-label="Close menu" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-slate-950/40 md:hidden" />}
      <aside className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-200 bg-white transition-transform md:sticky md:top-0 md:h-screen md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-14 items-center justify-between border-b border-slate-100 px-4">
          <Link href="/admin" className="text-lg font-extrabold tracking-tight text-emerald-700">Fresh2Cook <span className="text-slate-500">Admin</span></Link>
          <button onClick={() => setOpen(false)} className="rounded-lg px-2 py-1 text-slate-500 md:hidden">✕</button>
        </div>
        <div className="border-b border-slate-100 px-4 py-3">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Operations Workspace</p>
          <p className="mt-1 text-sm font-semibold">Admin Control Panel</p>
        </div>
        <nav className="flex-1 space-y-4 overflow-y-auto p-3">
          {groups.map((group) => (
            <div key={group.title}>
              <p className="mb-1 px-3 text-[10px] font-bold tracking-[0.16em] text-slate-400">{group.title}</p>
              <div className="space-y-0.5">
                {group.links.map(([label, href]) => {
                  const active = pathname === href || (href !== "/admin" && pathname.startsWith(href + "/"));
                  return (
                    <Link key={href} href={href} onClick={() => setOpen(false)}
                      className={`flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition ${active ? "bg-emerald-50 text-emerald-800 ring-1 ring-emerald-100" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`}>
                      <span>{label}</span>
                      {active && <span className="h-1.5 w-1.5 rounded-full bg-emerald-600" />}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="border-t border-slate-100 p-3">
          <Link href="/" className="block rounded-lg px-3 py-2 text-sm font-medium text-slate-500 hover:bg-slate-50">← Open Storefront</Link>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200 bg-white/95 px-3 backdrop-blur sm:px-5">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(true)} aria-label="Open navigation" className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm md:hidden">☰</button>
            <div>
              <p className="text-sm font-bold">Admin Workspace</p>
              <p className="hidden text-[11px] text-slate-400 sm:block">Orders · Inventory · Delivery · Team</p>
            </div>
          </div>
          <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">Operations</span>
        </header>
        <main className="mx-auto w-full max-w-[1800px] p-3 sm:p-4 lg:p-5">{children}</main>
      </div>
    </div>
  );
}

