﻿import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: true,
    module: "Live Order Tracking",
    timestamp: new Date().toISOString()
  });
}





