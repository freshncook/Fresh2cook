﻿import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: true,
    module: "Refund Engine",
    timestamp: new Date().toISOString()
  });
}





